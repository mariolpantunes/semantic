#!/bin/bash

if [ $# -lt 1 ]
then
	echo "Mode [client/server/broker] and Runs must be specified"
	exit 1
fi

path="../"
modes=( "one-by-one" "one-at-once" "all-at-once" )
query='{"id":"0000","query":["temperature","air","indoor","domotic"]}'
services='{"type":"services","services":[{"name":"/it/domotic/temp","id":0,"meta":"input:X,output:Y,location:Z","description":["temperature","air","indoor","domotic"]},{"name":"/it/city/parking","id":1,"meta":"input:X,output:Y,location:Z","description":["magnetic","field","parking","city"]},{"name":"/it/environment/temp","id":2,"meta":"input:X,output:Y,location:Z","description":["temperature","forest","fire","environment"]},{"name":"/it/water/quality","id":3,"meta":"input:X,output:Y,location:Z","description":["pH","quality","potable","water"]},{"name":"/it/farming/ch4","id":4,"meta":"input:X,output:Y,location:Z","description":["CH4","gases","toxic","farming"]},{"name":"/it/agriculture/moisture","id":5,"meta":"input:X,output:Y,location:Z","description":["moisture","greenhouse","soil","agriculture"]},{"name":"/it/health/pulse","id":6,"meta":"input:X,output:Y,location:Z","description":["pulse","count","sportsman","health"]},{"name":"/it/security/isobutane","id":7,"meta":"input:X,output:Y,location:Z","description":["isobutane","gases","explosive","security"]},{"name":"/it/logistic/gps","id":8,"meta":"input:X,output:Y,location:Z","description":["gps","fleet","tracking","logistic"]},{"name":"/it/industrial/ozone","id":9,"meta":"input:X,output:Y,location:Z","description":["ozone","presence","gases","industrial"]},{"name":"/it/domotic/door","id":10,"meta":"input:X,output:Y,location:Z","description":["infrared","door","intrusion","domotic"]},{"name":"/it/city/noise","id":11,"meta":"input:X,output:Y,location:Z","description":["microphone","ambient","noise","city"]},{"name":"/it/environment/level","id":12,"meta":"input:X,output:Y,location:Z","description":["level","ultrasound","snow","environment"]},{"name":"/it/water/flow","id":13,"meta":"input:X,output:Y,location:Z","description":["flow","liquid","leakage","water"]},{"name":"/it/farming/humidity","id":14,"meta":"input:X,output:Y,location:Z","description":["humidity","gases","offspring","farming"]},{"name":"/it/agriculture/wetness","id":15,"meta":"input:X,output:Y,location:Z","description":["wetness","leaf","greenhouse","agriculture"]},{"name":"/it/health/respiration","id":16,"meta":"input:X,output:Y,location:Z","description":["respiration","patient","surveillance","health"]},{"name":"/it/security/gamma","id":17,"meta":"input:X,output:Y,location:Z","description":["gamma","level","radiation","security"]},{"name":"/it/logistic/location","id":18,"meta":"input:X,output:Y,location:Z","description":["tag","location","item","logistic"]},{"name":"/it/industrial/CO2","id":19,"meta":"input:X,output:Y,location:Z","description":["CO2","quality","air","industrial"]},{"name":"/it/domotic/voltage","id":20,"meta":"input:X,output:Y,location:Z","description":["voltage","level","metering","domotic"]},{"name":"/it/city/light","id":21,"meta":"input:X,output:Y,location:Z","description":["light","control","road","city"]},{"name":"/it/environment/","id":22,"meta":"input:X,output:Y,location:Z","description":["accelerometer","detection","earthquake","environment"]},{"name":"/it/water/floods","id":23,"meta":"input:X,output:Y,location:Z","description":["ultrasound","floods","river","water"]},{"name":"/it/farming/tag","id":24,"meta":"input:X,output:Y,location:Z","description":["tag","passive","tracking","farming"]},{"name":"/it/agriculture/wind","id":25,"meta":"input:X,output:Y,location:Z","description":["wind","speed","meteorological","agriculture"]},{"name":"/it/health/fall","id":26,"meta":"input:X,output:Y,location:Z","description":["fall","accelerometer","detection","health"]},{"name":"/it/security/water","id":27,"meta":"input:X,output:Y,location:Z","description":["water","presence","liquid","security"]},{"name":"/it/logistic/vibration","id":28,"meta":"input:X,output:Y,location:Z","description":["vibrations","condition","shipment","logistic"]},{"name":"/it/industrial/vibration","id":29,"meta":"input:X,output:Y,location:Z","description":["accelerometer","vibration","device","industrial"]}]}'

next_start=$(date +%s)

echo "Starting Experiment"

count=30

for mode in ${modes[@]}
do

next_start=$(( next_start + 45 ))

echo ""
echo "--------------------------"
echo "Registration Mode: $mode"
echo "Service Count: $count"
echo "--------------------------"
echo ""

#Starting NFD
echo "Starting NFD"
nfd-start >> ../logs/nfd\_$1\_$mode\_$count.log 2>&1
sleep 5

if [ $1 != "broker" ]
then
	echo "Adding next-hop /it"
	nfdc register /it udp://192.168.0.1:6363 >> ../logs/nfd\_$1\_$run\_$mode\_$count.log
else
	sudo tcpdump port 6363 -i any -w ../logs/ndn\_$1\_$mode\_$count.dump &
	tcpdumpPID=$!
fi

#Starting Experiment
if [ $1 = "server" ]
then
sleep 6
echo "Starting Services"
$path"build/service-provider" $services $mode $count >> ../logs/services\_$1\_$mode\_$count.log &
servicesPID=$!
elif [ $1 = "client" ]
then
sleep 9
echo "Starting Client"
$path"build/client" $query >> ../logs/client\_$1\_$mode\_$count.log &
clientPID=$!
elif [ $1 = "broker" ]
then
sleep 3
echo "Starting Broker"
$path"build/broker" 10.5.15.30 6363 >> ../logs/broker\_$1\_$mode\_$count.log &
brokerPID=$!
else	
	echo "Mode [client/server/broker] must be specified"
	nfd-stop
	exit 1
fi

#Stoping Experiment
if [ $1 = "server" ]
then
sleep 22
echo "Stopping Services"
kill $servicesPID
sleep 6
elif [ $1 = "client" ]
then
sleep 16
echo "Stopping Client"
kill $clientPID
sleep 9
elif [ $1 = "broker" ]
then
sleep 28
echo "Stopping Broker"
kill $brokerPID
sleep 3
else	
	echo "Mode [client/server/broker] must be specified"
	nfd-stop
	exit 1
fi

#Stopping NFD
echo "Stopping NFD"
nfd-stop
if [ $1 = "broker" ]
then
	kill $tcpdumpPID
fi

sleep_seconds=$(( next_start - $(date +%s) ))
sleep $sleep_seconds

done