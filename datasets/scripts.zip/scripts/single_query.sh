#!/bin/bash

path="../"
while read query
do
	if echo "$query" | grep -q "$1"; then
  		$path"build/client" $query >> $path"/logs/client_all_queries.log"
	fi
done < $path"queries.json"
