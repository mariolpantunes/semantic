#!/usr/bin/python

import os
import sys

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *
import numpy as np
import scipy as sp
import scipy.stats
import math

def getStats(data, confidence=0.95):
	rows = data.shape[0]
	columns = data.shape[1]
	output = np.zeros((4,columns),dtype=np.float)
	for column in range(columns):
		a = data[:,column]
		n = len(a)
		m, se = np.mean(a), scipy.stats.sem(a)
		h = se * sp.stats.t._ppf((1+confidence)/2., n-1)
		output[:,column] = [m, h, max(m-h,0.0) , m+h]
	return output

path = "../logs/network"
modes = ["one-by-one", "one-at-once", "all-at-once"]

queryResults = {}
registrationResults = {}
unregistrationResults = {}
failed = set()

for filename in os.listdir(path):
	if not("_" in filename):
		continue
	splittedName = filename.split(".")[0].split('_')
	appType = splittedName[0]
	hostName = splittedName[1] 
	run = int(splittedName[2])
	mode = splittedName[3]
	serviceCount = int(splittedName[4])
	if appType == "client" and mode == "one-by-one":
		sentBool = False
		receivedBool = False
		for line in open(path+'/'+filename):
			if "Sending Query" in line:
				sent = line.split(" ")[0]
				sentBool = True
			elif "Receiving Reply" in line:
				received = line.split(" ")[0]
				receivedBool = True
		if sentBool and receivedBool:
			serviceTime = (float(received) - float(sent))/1000
			row = run - 1
			column = serviceCount - 1
			initialZeros = np.zeros((10,30),dtype = float)
			level0 = queryResults.get(mode,initialZeros)
			level0[row,column]=serviceTime
			queryResults[mode]=level0
		else:
			failed.add((mode,run,serviceCount))
			print "ERROR: Missing element in " + filename
	elif appType == "services":
		sentAddCount = 0
		receivedAddCount = 0
		sentDelCount = 0
		receivedDelCount = 0
		for line in open(path+'/'+filename):
			if "Sending Registration Request" in line:
				if sentAddCount == 0:	
					sentAdd = line.split(" ")[0]
				sentAddCount += 1
			elif "Receiving Registration Response" in line:
				receivedAdd = line.split(" ")[0]
				receivedAddCount += 1
			elif "Sending Unregistration Request" in line:
				if sentDelCount == 0:	
					sentDel = line.split(" ")[0]
				sentDelCount += 1
			elif "Receiving Unregistration Response" in line:
				receivedDel = line.split(" ")[0]
				receivedDelCount += 1
		if (receivedAddCount == sentAddCount) and (sentAddCount > 0):
			serviceTime = (float(receivedAdd) - float(sentAdd))/1000
			row = run - 1
			column = serviceCount - 1
			initialZeros = np.zeros((10,30),dtype = float)
			level0 = registrationResults.get(mode,initialZeros)
			level0[row,column]=serviceTime
			registrationResults[mode]=level0
		else:
			print "ERROR: Missing registration element in " + filename
			failed.add((mode,run,serviceCount))

		if (receivedDelCount == sentDelCount) and (sentDelCount > 0):
			serviceTime = (float(receivedDel) - float(sentDel))/1000
			row = run - 1
			column = serviceCount - 1
			initialZeros = np.zeros((10,30),dtype = float)
			level0 = unregistrationResults.get(mode,initialZeros)
			level0[row,column]=serviceTime
			unregistrationResults[mode]=level0
		else:
			print "ERROR: Missing unregistration element in " + filename
			failed.add((mode,run,serviceCount))	

f = open('../out/failure.log','w')
out = ""
for item in failed:
	for element in item:
		out += str(element) + " "
	out += '\n'
f.write(out)
f.close()

linestyles = ['-', '--', '-.', ':']
pdf = PdfPages('../out/service-time.pdf')
colors = ['r','g','b']
for results in [queryResults, registrationResults, unregistrationResults]:
	i = 0
        fig = plt.figure()
	ax = plt.gca()
	fig.set_size_inches(6,4)
	plt.rc('font', size='9')	
	for mode in results.keys():
		data = results[mode]
		x = np.linspace(1,30,30)
		y = getStats(data)
		xticks = 5*np.arange(7)
		xticks[0]=1
		ax.set_xticks(xticks, minor=False)
		#plt.errorbar( x, y[0], yerr=y[1], linestyle=linestyles[i], label = mode, color=colors[mode])
                plt.plot(x, y[0], linestyle=linestyles[i], label = mode, color=colors[i])
		plt.fill_between(x,y[2],y[3],alpha=0.3,lw=0.0, facecolor = colors[i])
                i+=1
	plt.xlabel("Number of Services")
	plt.ylabel("Service Time (ms)")

	# subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
	# fig.tight_layout()
	if len(results.keys()) > 1:
		plt.legend(loc="upper left", frameon=False)
	pdf.savefig()
	plt.close()

pdf.close()
