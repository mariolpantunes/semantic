#!/usr/bin/python

import os
import sys
import json

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pylab import *
import numpy as np
import math

#Auxiliar Functions

def getStats(data, confidence=0.95):
	rows = data.shape[0]
	columns = data.shape[1]
	output = np.zeros((columns,3),dtype=np.float)
	for row in range(rows):
		a = data[[row]]
		n = len(a)
		m, se = np.mean(a), scipy.stats.sem(a)
		h = se * sp.stats.t._ppf((1+confidence)/2., n-1)
		output[:,row] = np.array([m, m-h, m+h])
	return output

def precision (relevant,received):
    """Computes the precision of a reply.
    """
    receivedRelevants = 0.0
    for item in received:
        if item in relevant:
            receivedRelevants+=1
    return receivedRelevants/len(received)

def averagePrecision (relevant, received):
    """Computes the average precision of a reply.
    """
    result = 0.0
    for k in range(len(received)):
        if received[k] in relevant:
            result+=precision(relevant,received[:k+1])
    return result/len(relevant)


logFile = "../logs/semantic-matcher.log"

groups = {00:"M2M",10:"E2M(1/1)",11:"E2M(1/2)",12:"E2M(2/2)",20:"U2M(1)",21:"U2M(2)",22:"U2M(3)",23:"U2M(4)"}

sortedGroups = []
for key in sorted(groups.keys()):
	sortedGroups+=[groups[key]]

variants=["precision","count"]
methods = ["jaccard","cosine"]
submethods = ["string","levenshtein","semantic"]

columnCount = len(sortedGroups)

results = {}

count = 0

#Starting Parsing
print "Starting Parsing"

mode = 0
ready = False
last = 0
timeCount = 0
queryCount = 0

for line in open(logFile):
	if ("RECV MSG" in line):
		strippedLine = line.strip().split(' ')
		oid = int(strippedLine[-1])
		if ready and ("query" in line):
			if oid < last:
				if queryCount!=30:
					raise Exception("Too few queries ...")
				#Inversion => New Mode
				queryCount = 0
				mode += 1
				if mode>len(sortedGroups)-1:
					raise Exception("Too many modes ...")
				print sortedGroups[mode]
			last = oid
			timeCount = 0
			queryCount += 1
		if oid == 299:
			#After a complete all_queries
			ready = True
	elif ("SEND MSG:" in line) and ("query" in line) and ready:
		strippedLine = line.strip().split(' ')
		oid = int(strippedLine[-1])
		if timeCount!=len(methods)*len(submethods):
			raise Exception("One combination mehtod/submethod is missing ...")
	elif ("ProcessingTime" in line) and ready:
		timeCount += 1
		splittedLine = line.strip().split('(')[1].split(')')[0].split(',')
		method = splittedLine[0].lower()
		submethod = splittedLine[1].lower()
		value = float(line.split(' ')[-1])/1000
		print method, submethod, value, queryCount
		initialTimes = np.zeros((30,columnCount),dtype=np.float)
		level1 = results.get(method,{})
		level2 = level1.get(submethod,initialTimes)
		level2[[queryCount-1],[mode]]=value
		level1[submethod] = level2
		results[method] = level1

if mode<len(sortedGroups)-1:
	raise Exception("Too few modes ...")

#Make Graphics
pdf = PdfPages('../out/heatmaps-time.pdf')

# Plot it out
for method in methods:
	data = []
	for i in range(len(submethods)):
		submethod = submethods[i]
		data = results[method][submethod]

		plt.subplot(1,len(submethods),i+1)
		plt.pcolor(data, cmap=plt.cm.Blues, alpha=0.8)
		plt.title(submethod.capitalize())
		# Format
		fig = plt.gcf()
		# get the axis
		ax = plt.gca()
		# turn off the frame
		# ax.set_frame_on(False)
		# put the major ticks at the middle of each cell
		ax.set_xticks(np.arange(data.shape[1]) + 0.5, minor=False)
		for t in ax.xaxis.get_major_ticks():
		    t.tick1On = False
		    t.tick2On = False
		for t in ax.yaxis.get_major_ticks():
		    t.tick1On = False
		    t.tick2On = False
		ax.grid(False)
		ax.set_xlim(0,data.shape[1])
		ax.set_xticklabels(sortedGroups, minor=False)
		plt.xticks(rotation=90)

		if i==0:
			plt.ylabel("Queries")
			precisionYLabels = range(data.shape[0])
			ax.set_yticks(np.arange(data.shape[0]) + 0.5, minor=False)
			ax.set_yticklabels(precisionYLabels, minor=False)
		else:
			ax.set_yticks([], minor=False)

		if i==len(submethods)-1:
			plt.colorbar(label="Processing Time (ms)")
			fig.set_size_inches(12,12)

	subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
	fig.tight_layout()
	pdf.savefig()
	plt.close()

pdf.close()


pdf = PdfPages('../out/boxplot-time.pdf')
medianprops = dict(linewidth=4)
for method in methods:
	data = []
	for i in range(len(submethods)):
		submethod = submethods[i]
		data = results[method][submethod]
		plt.subplot(1,len(submethods),i+1)
		plt.rc('font', size='9')
		plt.boxplot(data, labels = sortedGroups, medianprops = medianprops, whis=[5,95])
		plt.title(submethod.capitalize())
		fig = plt.gcf()
		ax = plt.gca()
		plt.xticks(rotation=90)
		if i==0:
			plt.ylabel("Processing Time (ms)")
		if i==len(submethods)-1:
			fig.set_size_inches(6,3)

	subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
	fig.tight_layout()
	pdf.savefig()
	plt.close()

pdf.close()
