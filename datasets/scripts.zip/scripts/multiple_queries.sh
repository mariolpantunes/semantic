#!/bin/bash

path="../"
modes=( "00" "10" "11" "12" "20" "21" "22" "23" )
services='{"type":"services","services":[{"name":"/it/domotic/temp","id":0,"meta":"input:X,output:Y,location:Z","description":["temperature","air","indoor","domotic"]},{"name":"/it/city/parking","id":1,"meta":"input:X,output:Y,location:Z","description":["magnetic","field","parking","city"]},{"name":"/it/environment/temp","id":2,"meta":"input:X,output:Y,location:Z","description":["temperature","forest","fire","environment"]},{"name":"/it/water/quality","id":3,"meta":"input:X,output:Y,location:Z","description":["pH","quality","potable","water"]},{"name":"/it/farming/ch4","id":4,"meta":"input:X,output:Y,location:Z","description":["CH4","gases","toxic","farming"]},{"name":"/it/agriculture/moisture","id":5,"meta":"input:X,output:Y,location:Z","description":["moisture","greenhouse","soil","agriculture"]},{"name":"/it/health/pulse","id":6,"meta":"input:X,output:Y,location:Z","description":["pulse","count","sportsman","health"]},{"name":"/it/security/isobutane","id":7,"meta":"input:X,output:Y,location:Z","description":["isobutane","gases","explosive","security"]},{"name":"/it/logistic/gps","id":8,"meta":"input:X,output:Y,location:Z","description":["gps","fleet","tracking","logistic"]},{"name":"/it/industrial/ozone","id":9,"meta":"input:X,output:Y,location:Z","description":["ozone","presence","gases","industrial"]},{"name":"/it/domotic/door","id":10,"meta":"input:X,output:Y,location:Z","description":["infrared","door","intrusion","domotic"]},{"name":"/it/city/noise","id":11,"meta":"input:X,output:Y,location:Z","description":["microphone","ambient","noise","city"]},{"name":"/it/environment/level","id":12,"meta":"input:X,output:Y,location:Z","description":["level","ultrasound","snow","environment"]},{"name":"/it/water/flow","id":13,"meta":"input:X,output:Y,location:Z","description":["flow","liquid","leakage","water"]},{"name":"/it/farming/humidity","id":14,"meta":"input:X,output:Y,location:Z","description":["humidity","gases","offspring","farming"]},{"name":"/it/agriculture/wetness","id":15,"meta":"input:X,output:Y,location:Z","description":["wetness","leaf","greenhouse","agriculture"]},{"name":"/it/health/respiration","id":16,"meta":"input:X,output:Y,location:Z","description":["respiration","patient","surveillance","health"]},{"name":"/it/security/gamma","id":17,"meta":"input:X,output:Y,location:Z","description":["gamma","level","radiation","security"]},{"name":"/it/logistic/location","id":18,"meta":"input:X,output:Y,location:Z","description":["tag","location","item","logistic"]},{"name":"/it/industrial/CO2","id":19,"meta":"input:X,output:Y,location:Z","description":["CO2","quality","air","industrial"]},{"name":"/it/domotic/voltage","id":20,"meta":"input:X,output:Y,location:Z","description":["voltage","level","metering","domotic"]},{"name":"/it/city/light","id":21,"meta":"input:X,output:Y,location:Z","description":["light","control","road","city"]},{"name":"/it/environment/","id":22,"meta":"input:X,output:Y,location:Z","description":["accelerometer","detection","earthquake","environment"]},{"name":"/it/water/floods","id":23,"meta":"input:X,output:Y,location:Z","description":["ultrasound","floods","river","water"]},{"name":"/it/farming/tag","id":24,"meta":"input:X,output:Y,location:Z","description":["tag","passive","tracking","farming"]},{"name":"/it/agriculture/wind","id":25,"meta":"input:X,output:Y,location:Z","description":["wind","speed","meteorological","agriculture"]},{"name":"/it/health/fall","id":26,"meta":"input:X,output:Y,location:Z","description":["fall","accelerometer","detection","health"]},{"name":"/it/security/water","id":27,"meta":"input:X,output:Y,location:Z","description":["water","presence","liquid","security"]},{"name":"/it/logistic/vibration","id":28,"meta":"input:X,output:Y,location:Z","description":["vibrations","condition","shipment","logistic"]},{"name":"/it/industrial/vibration","id":29,"meta":"input:X,output:Y,location:Z","description":["accelerometer","vibration","device","industrial"]}]}'
for mode in ${modes[@]}
do
	echo "Mode :"$mode
	echo "Starting NFD"
	nfd-start >> /tmp/nfd.log 2>&1
	sleep 5
	echo "Starting Broker"
	$path"build/broker" 10.5.15.30 6363 >> /tmp/broker.log &
	brokerPID=$!
	sleep 5
	echo "Starting Services"
	$path"build/service-provider" $services one-at-once 30 >> /tmp/services.log &
	servicesPID=$!
	sleep 5
	while read query
	do
		if echo "$query" | grep -q id\":\"$mode ; then
			echo $query
	  		$path"build/client" $query >> $path"/logs/client_all_queries.log" &
	  		clientPID=$!
			sleep 5
		fi
	done < $path"queries.json"
	sleep 5
	echo "Stopping Services"
	kill $servicesPID
	sleep 5 
	echo "Stopping Broker"
	kill $brokerPID
	sleep 5
	echo "Stopping NFD"
	nfd-stop
	sleep 5
done



