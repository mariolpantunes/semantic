#!/bin/bash

runs=$(seq 1 $1)
counts=$(seq 1 $2)
modes=( "one-by-one" "one-at-once" "all-at-once" )

for run in ${runs[@]}
do

for count in ${counts[@]}
do

for mode in ${modes[@]}
do

echo ""
echo "--------------------------"
echo "Run: $run"
echo "Registration Mode: $mode"
echo "Service Count: $count"
echo "--------------------------"
echo ""

ssh amazing@10.110.1.15 '/home/amazing/apps/scripts/single_experiment.sh broker '$run' '$count' '$mode' &' &
ssh amazing@10.110.1.8 '/home/amazing/apps/scripts/single_experiment.sh server '$run' '$count' '$mode' &' &
ssh amazing@10.110.1.20 '/home/amazing/apps/scripts/single_experiment.sh client '$run' '$count' '$mode' &' &

sleep 45

done
done
done